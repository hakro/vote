# Purpose
This is a small website intended for demonstrating the capabilites of Docker & Docker Swarm during a Dojo at Skale-5.
www.skale-5.com
