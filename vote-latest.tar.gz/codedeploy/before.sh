#!/bin/bash

echo "Début du déploiement de $APPLICATION_NAME - $DEPLOYMENT_GROUP_NAME" > /var/www/html/before.php
