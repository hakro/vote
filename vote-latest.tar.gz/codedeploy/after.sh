#!/bin/bash

echo "Déploiement de $APPLICATION_NAME - $DEPLOYMENT_GROUP_NAME terminé" > /var/www/html/after.php
